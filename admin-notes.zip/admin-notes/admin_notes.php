<?php
/**
 * Plugin Name: Admin Notes
 * Description: Simple dashboard notes for administrators.
 * Version: 1.0.0
 * Author: Daniel Betinský
 * Text Domain: admin-notes
 */

if (!defined('ABSPATH')) {
    exit;
}

define('AN_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('AN_PLUGIN_URL', plugin_dir_url(__FILE__));
define('AN_PLUGIN_VERSION', '1.0.0');

require_once AN_PLUGIN_PATH . 'admin/dashboard-widget.php';