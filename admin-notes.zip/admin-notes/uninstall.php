<?php

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

delete_option('an_note');
delete_option('an_note_updated_at');