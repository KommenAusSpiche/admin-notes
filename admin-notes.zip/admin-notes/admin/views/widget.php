<form method="post">
    <?php wp_nonce_field('an_save_note', 'an_nonce'); ?>

    <textarea
        name="an_note"
        class="an-textarea"
        placeholder="Write your notes here..."
    ><?php echo esc_textarea($note); ?></textarea>

    <p>
        <button type="submit" class="button button-primary">
            Save Notes
        </button>
    </p>

    <?php if (!empty($updated_at)) : ?>
        <p class="an-meta">
            Last Updated: <?php echo esc_html($updated_at); ?>
        </p>
    <?php endif; ?>
</form>