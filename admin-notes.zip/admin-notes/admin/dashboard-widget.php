<?php

if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_dashboard_setup', 'an_register_dashboard_widget');
add_action('admin_enqueue_scripts', 'an_enqueue_admin_assets');

function an_register_dashboard_widget() {

    wp_add_dashboard_widget(
        'admin_notes_widget',
        __('📝 Admin Notes', 'admin-notes'),
        'an_dashboard_widget'
    );

}

function an_enqueue_admin_assets() {
    wp_enqueue_style(
        'admin-notes-admin',
        AN_PLUGIN_URL . 'assets/css/admin.css',
        [],
        AN_PLUGIN_VERSION
    );
}

function an_dashboard_widget() {

    if (!current_user_can('manage_options')) {
        echo '<p>' . esc_html__('You do not have permission to edit these notes.', 'admin-notes') . '</p>';
        return;
    }

    if (
        isset($_POST['an_note']) &&
        isset($_POST['an_nonce']) &&
        wp_verify_nonce($_POST['an_nonce'], 'an_save_note')
    ) {
        update_option('an_note', sanitize_textarea_field($_POST['an_note']));
        update_option('an_note_updated_at', current_time('mysql'));

        echo '<p><strong>' . esc_html__('Notes saved successfully ✅', 'admin-notes') . '</strong></p>';
    }

    $note = get_option('an_note', '');
    $updated_at = get_option('an_note_updated_at', '');

    if (!empty($updated_at)) {
        $updated_at = wp_date(
            'F j, Y H:i',
            strtotime($updated_at)
        );
    }

    require AN_PLUGIN_PATH . 'admin/views/widget.php';
}